const express = require("express");
const path = require("path");

const app = express();

// Serve static files (CSS & JS)
app.use(express.static(path.join(__dirname, "public")));

// Home Route
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "views", "index.html"));
});

// FAQ Route
app.get("/faq", (req, res) => {
    res.sendFile(path.join(__dirname, "views", "faq.html"));
});

// Room Booking Route
app.get("/booking", (req, res) => {
    res.sendFile(path.join(__dirname, "views", "booking.html"));
});

// Start Server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

