# CIS-2336-SP25-Project

Please update this README with the instructions on how to use the repository (developer documentation).

Use [GitHub Markdown](https://docs.github.com/en/get-started/writing-on-github/getting-started-with-writing-and-formatting-on-github) to oraginze and fromat your README document.
