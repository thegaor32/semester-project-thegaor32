

document.addEventListener("DOMContentLoaded", () => {
    // FAQ Toggle (already added)
    const questions = document.querySelectorAll(".faq-question");
    questions.forEach((question) => {
        question.addEventListener("click", () => {
            const answer = question.nextElementSibling;
            answer.style.display = (answer.style.display === "block") ? "none" : "block";
        });
    });

    // ✅ Room Booking Form Validation
    const bookingForm = document.getElementById("booking-form");
    if (bookingForm) {
        bookingForm.addEventListener("submit", (event) => {
            event.preventDefault(); // Prevent page reload

            const name = document.getElementById("name").value.trim();
            const email = document.getElementById("email").value.trim();
            const room = document.getElementById("room").value;
            const date = document.getElementById("date").value;
            const time = document.getElementById("time").value;
            const confirmation = document.getElementById("confirmation");

            if (name === "" || email === "" || room === "" || date === "" || time === "") {
                alert("Please fill out all fields.");
                return;
            }

            // ✅ Display Confirmation Message
            confirmation.style.display = "block";
            confirmation.textContent = `Your room has been booked for ${date} at ${time}.`;

            // Clear form
            bookingForm.reset();
        });
    }
});

document.addEventListener("DOMContentLoaded", () => {
    const bookingForm = document.getElementById("booking-form");

    if (bookingForm) {
        bookingForm.addEventListener("submit", async (event) => {
            event.preventDefault();

            const formData = {
                name: document.getElementById("name").value,
                email: document.getElementById("email").value,
                room: document.getElementById("room").value,
                date: document.getElementById("date").value,
                time: document.getElementById("time").value
            };

            const response = await fetch("/api/book-room", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(formData)
            });

            const result = await response.json();
            alert(result.message);
        });
    }
});
